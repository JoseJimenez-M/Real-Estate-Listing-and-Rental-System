<footer class="bg-light text-center text-lg-start mt-5">
    <div class="text-center p-3">
        © 2025 Real Estate Rental System
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
